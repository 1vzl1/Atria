Please refer to the [Github ngCordova Releases file](https://github.com/driftyco/ng-cordova/releases) for detailed information.
